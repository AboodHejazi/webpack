test('API should return 200 on successful request', () => {
    expect(true).toBe(true); 
  });